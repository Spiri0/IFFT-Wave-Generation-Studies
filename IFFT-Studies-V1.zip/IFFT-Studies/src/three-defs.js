import * as THREE from "../resources/libs/three/build/three.module.js";
import { OrbitControls } from '../resources/libs/three/examples/jsm/controls/OrbitControls.js';
import WebGL from '../resources/libs/three/examples/jsm/WebGL.js';

import { RenderPass } from '../resources/libs/three/examples/jsm/postprocessing/RenderPass.js'; 
import { ShaderPass } from '../resources/libs/three/examples/jsm/postprocessing/ShaderPass.js';
import { EffectComposer } from '../resources/libs/three/examples/jsm/postprocessing/EffectComposer.js'; 
import {CopyShader} from '../resources/libs/three/examples/jsm/shaders/CopyShader.js'; 

export {THREE, OrbitControls, WebGL, RenderPass, ShaderPass, EffectComposer, CopyShader};