import {THREE} from '../three-defs.js';


export const ocean_constants = (function() {
  return {

		QT_OCEAN_MIN_CELL_SIZE: 24,	
		QT_OCEAN_MIN_CELL_RESOLUTION: 48,
		OCEAN_SIZE: 100000,

  }
})();