import {THREE} from '../three-defs.js';


const _D = new THREE.Vector3();
const _D1 = new THREE.Vector3();
const _D2 = new THREE.Vector3();
const _P = new THREE.Vector3();
const _P1 = new THREE.Vector3();
const _P2 = new THREE.Vector3();
const _P3 = new THREE.Vector3();
const _N = new THREE.Vector3();
const _N1 = new THREE.Vector3();
const _N2 = new THREE.Vector3();
const _N3 = new THREE.Vector3();


class OceanBuilderThreadedWorker {
  constructor() {
  }

  Init(params) {
    this.cachedParams_ = {...params};
    this.params_ = params;
    this.params_.offset = new THREE.Vector3(...params.offset);
  }


  GenerateNormals_(positions, indices) {
    const normals = new Array(positions.length).fill(0.0);
    for (let i = 0, n = indices.length; i < n; i+= 3) {
      const i1 = indices[i] * 3;
      const i2 = indices[i+1] * 3;
      const i3 = indices[i+2] * 3;

      _N1.fromArray(positions, i1);
      _N2.fromArray(positions, i2);
      _N3.fromArray(positions, i3);

      _D1.subVectors(_N3, _N2);
      _D2.subVectors(_N1, _N2);
      _D1.cross(_D2);

      normals[i1] += _D1.x;
      normals[i2] += _D1.x;
      normals[i3] += _D1.x;

      normals[i1+1] += _D1.y;
      normals[i2+1] += _D1.y;
      normals[i3+1] += _D1.y;

      normals[i1+2] += _D1.z;
      normals[i2+2] += _D1.z;
      normals[i3+2] += _D1.z;
    }
    return normals;
  }

	//the indices for the bufferGeometry triangle vertices ccw (right hand coordinate system)
  GenerateIndices_() {
    const resolution = this.params_.resolution + 2;
    const indices = [];
    for (let i = 0; i < resolution; i++) {
      for (let j = 0; j < resolution; j++) {
        indices.push(
            i * (resolution + 1) + j,
            (i + 1) * (resolution + 1) + j + 1,
            i * (resolution + 1) + j + 1);
        indices.push(
            (i + 1) * (resolution + 1) + j,
            (i + 1) * (resolution + 1) + j + 1,
            i * (resolution + 1) + j);
      }
    }
    return indices;
  }


  NormalizeNormals_(normals) {
    for (let i = 0, n = normals.length; i < n; i+=3) {
      _N.fromArray(normals, i);
      _N.normalize();
      normals[i] = _N.x;
      normals[i+1] = _N.y;
      normals[i+2] = _N.z;
    }
  }
  

	Rebuild() {
		const positions = [];
		const coords = [];
		const vindices = [];

		
		const localToWorld = this.params_.worldMatrix;
		const resolution = this.params_.resolution + 2;
		const offset = this.params_.offset;
		const width = this.params_.width;
		const half = width / 2;
		const effectiveResolution = resolution - 2;

		let idx = 0;

		for (let x = -1; x <= effectiveResolution + 1; x++) {
			const xp = width * x / effectiveResolution;
			for (let y = -1; y <= effectiveResolution + 1; y++) {
				const yp = width * y / effectiveResolution;

				// Compute position
				_P.set(xp - half, yp - half, 0);
				_P.add(offset);
				_P.applyMatrix4(localToWorld);

				positions.push(_P.x, _P.y, _P.z);
				coords.push(_P.x, _P.y, _P.z);		//here the same like positions
				vindices.push(idx);
				idx += 1;				
			}
		}


		const indices = this.GenerateIndices_();
		const normals = this.GenerateNormals_(positions, indices);

		this.NormalizeNormals_(normals);

		const bytesInFloat32 = 4;
		const bytesInInt32 = 4;
		
		//I use SharedArrayBuffer. For that i have the coi service worker script to simulate cross origin isolation
		/*
		const positionsArray = new Float32Array(new SharedArrayBuffer(bytesInFloat32 * positions.length));
		const normalsArray = new Float32Array(new SharedArrayBuffer(bytesInFloat32 * normals.length));
		const coordsArray = new Float32Array(new SharedArrayBuffer(bytesInFloat32 * coords.length));
		const vindicesArray = new Uint32Array(new SharedArrayBuffer(bytesInInt32 * vindices.length));
		const indicesArray = new Uint32Array(new SharedArrayBuffer(bytesInInt32 * indices.length));
*/

		const positionsArray = new Float32Array(new ArrayBuffer(bytesInFloat32 * positions.length));
		const normalsArray = new Float32Array(new ArrayBuffer(bytesInFloat32 * normals.length));
		const coordsArray = new Float32Array(new ArrayBuffer(bytesInFloat32 * coords.length));
		const vindicesArray = new Uint32Array(new ArrayBuffer(bytesInInt32 * vindices.length));
		const indicesArray = new Uint32Array(new ArrayBuffer(bytesInInt32 * indices.length));

		positionsArray.set(positions, 0);
		normalsArray.set(normals, 0);
		coordsArray.set(coords, 0);
		vindicesArray.set(vindices, 0);
		indicesArray.set(indices, 0);


		return {
			positions: positionsArray,
			normals: normalsArray,
			coords: coordsArray,
			vindices: vindicesArray,
			indices: indicesArray,
			worldMatrix: this.params_.worldMatrix,
			resolution: this.params_.resolution,
			offset: this.params_.offset,
			width: this.params_.width,
			neighbours: this.params_.neighbours,
		};
	}
}//end class


const CHUNK = new OceanBuilderThreadedWorker();

self.onmessage = (msg) => {
	CHUNK.Init(msg.data.params);
	const rebuiltData = CHUNK.Rebuild();
	self.postMessage({data: rebuiltData});
};