import {THREE, ShaderPass} from './three-defs.js';
import {entity} from './entity.js';
import {threejs_component} from './threejs-component.js';
import {entity_manager} from './entity-manager.js';
//import {BasicController} from './basic-controller.js'; 
//import {ocean} from './ocean/ocean.js';

import {fft_generators} from './fft-generators.js';
import { commonVS } from "../resources/shader/IFFT/commonVS.js";
import { testFS } from "../resources/shader/IFFT/testFS.js";



class Main {

	constructor(){
	}

	Initialize() {   
		this.entityManager_ = new entity_manager.EntityManager();
		this.OnGameStarted();
	}

	OnGameStarted() {
		this.clock_ = new THREE.Clock();
		this.LoadControllers();
		this.previousRAF = null;
		this.RAF();
	}


  LoadControllers() {
  
		const threejs = new entity.Entity();
    	threejs.AddComponent(new threejs_component.ThreeJSController());
    	this.entityManager_.Add(threejs, 'threejs');

    	this.scene_ = threejs.GetComponent('ThreeJSController').scene_;
    	this.camera_ = threejs.GetComponent('ThreeJSController').camera_;
    	this.threejs_ = threejs.GetComponent('ThreeJSController');
		this.composer_ = threejs.GetComponent('ThreeJSController').composer_;

		const basicParams = {
			scene: this.scene_,
			camera: this.camera_,
		};

		//------------------------------------------------------------------------------------------------------------------------------------------

		this.camera_.position.set(0, 1000, 0);
//		this.player = new BasicController(basicParams);


		//***********************************************************************************
		//***********************Multithreading-Quadtree-Ocean****************************
		/*
		const ocean_ = new entity.Entity();
		ocean_.AddComponent(
			new ocean.OceanChunkManager({
				camera: this.camera_,
				scene: this.scene_,
				threejs: this.threejs_,
				sunpos: new THREE.Vector3(100000, 0, 100000),
				clock: this.clock_,
				wireframe: false,
     	})
     );
		this.entityManager_.Add(ocean_, 'ocean');		
		*/		
		//**********************************************************************************
		//**********************************************************************************


		const FFT_ = new entity.Entity();
		FFT_.AddComponent(
			new fft_generators.FFTGenerators({
				renderer: this.threejs_.threejs_,
				clock: this.clock_,
			})
		);
		this.entityManager_.Add(FFT_, 'fft');		
		
		
		//textures
		this.initialSpectrumFramebuffer = FFT_.components_.FFTGenerators.initialSpectrumFramebuffer.texture;
		this.pingPhaseFramebuffer = FFT_.components_.FFTGenerators.pingPhaseFramebuffer.texture;
		this.pongPhaseFramebuffer = FFT_.components_.FFTGenerators.pongPhaseFramebuffer.texture;
		this.spectrumFramebuffer = FFT_.components_.FFTGenerators.spectrumFramebuffer.texture;
		this.displacementFramebuffer= FFT_.components_.FFTGenerators.displacementMapFramebuffer.texture;
	
		
		//materials
		this.timeSpectrum = FFT_.components_.FFTGenerators.timeSpectrum;	//from paper
		this.materialInitialSpectrum = FFT_.components_.FFTGenerators.materialInitialSpectrum;
		this.materialSpectrum = FFT_.components_.FFTGenerators.materialSpectrum;
		this.materialPhase = FFT_.components_.FFTGenerators.materialPhase;
		this.materialOceanHorizontal = FFT_.components_.FFTGenerators.materialOceanHorizontal;
		this.materialOceanVertical = FFT_.components_.FFTGenerators.materialOceanVertical;


		//Test for frameBuffer textures because the composer needs a material
		var utest = {
			time: {value: this.clock_.getElapsedTime()},
			test: {value: this.displacementFramebuffer},		//texture: here i can check each texture
		}

		this.test = new THREE.RawShaderMaterial({
			glslVersion: THREE.GLSL3,
			uniforms: utest,
			vertexShader: commonVS,
			fragmentShader: testFS,
			depthTest: false,
		});


		

		this.composer_.addPass(new ShaderPass(this.test));
		//this.composer_.addPass(new ShaderPass(this.timeSpectrum));
		//this.composer_.addPass(new ShaderPass(this.materialInitialSpectrum));
		//this.composer_.addPass(new ShaderPass(this.materialPhase));		
		//this.composer_.addPass(new ShaderPass(this.materialSpectrum));		
		//this.composer_.addPass(new ShaderPass(this.materialOceanHorizontal));		
		//this.composer_.addPass(new ShaderPass(this.materialOceanVertical));		




		var light = new THREE.AmbientLight(0xffffff, 1); 
		this.scene_.add(light);

	}
	

	RAF() {
	
    requestAnimationFrame((t) => {
      if (this.previousRAF === null) {
        this.previousRAF = t;
      } else {
        this.Step(t - this.previousRAF);
        this.threejs_.Render();
        this.previousRAF = t;
      }

      setTimeout(() => {
        this.RAF();
      }, 1);
    });
  }
  
  
  Step(timeElapsed) { 
    const timeElapsedS = Math.min(1.0 / 30.0, timeElapsed * 0.001);
//    this.player.Update(0.01);//hack, just a fast implementation
    this.entityManager_.Update(timeElapsedS, 0);
  }

}


export {Main}

