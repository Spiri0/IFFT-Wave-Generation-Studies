export const displacementVerticalFS = `

	precision highp float;
	precision highp int;
	precision highp sampler2D;
	
	#define PI 3.141592653589793238
	
	in vec2 vUv;
	out vec4 outColor;

	uniform sampler2D u_input;
	uniform float transformSize;
	uniform float subtransformSize;

	vec2 multiplyComplex(vec2 a, vec2 b){
		return vec2(a.x * b.x - a.y * b.y, a.y * b.x + a.x * b.y);
	}
	
	void main(){

		float index = vUv.y * transformSize - 0.5;		// vertical

		float evenIndex = floor(index / subtransformSize) * (subtransformSize * 0.5) + mod(index, subtransformSize * 0.5);

		vec4 even = texture(u_input, vec2(gl_FragCoord.x, evenIndex+0.5)/transformSize).rgba;
		vec4 odd = texture(u_input, vec2(gl_FragCoord.x, evenIndex+transformSize*0.5+0.5)/transformSize).rgba;

		float twiddleArgument = -2.0*PI*(index/subtransformSize);
		vec2 twiddle = vec2(cos(twiddleArgument), sin(twiddleArgument));
		vec2 outputA = even.xy + multiplyComplex(twiddle, odd.xy);
		vec2 outputB = even.zw + multiplyComplex(twiddle, odd.zw);
		outColor = vec4(outputA,outputB);
		//outColor = vec4(0.0, 1.0, 1.0, 1.0);
	}
`;
