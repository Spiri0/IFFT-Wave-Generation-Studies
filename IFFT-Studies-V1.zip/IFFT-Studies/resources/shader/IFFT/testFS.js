export const testFS = `

	precision highp float;
	precision highp int;
	//precision highp sampler2DArray;
	//precision highp sampler3D;
	precision highp sampler2D;
	

	uniform sampler2D test;
	uniform float time;


	in vec2 vUv;
	out vec4 outColor;


	void main(){

		vec3 color = texture(test, vUv).rgb;
		outColor = vec4(color, 1.0);
	}
`;

