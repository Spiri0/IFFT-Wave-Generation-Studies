export const headerVS = `

	precision highp float;
	precision highp int;
	precision highp sampler2D;


	uniform mat4 modelMatrix;
	uniform mat4 modelViewMatrix;
	uniform mat4 viewMatrix;
	uniform mat4 projectionMatrix;
	uniform vec3 cameraPosition;

	uniform float time;

	uniform mat4 wMatrix;
	uniform int resolution;
	uniform vec3 offset;
	uniform vec3 origin;
	uniform float width;	
	uniform vec4 neighbours;

	uniform sampler2D vertexTexture;
	uniform sampler2D normalTexture;
	
	uniform sampler2D noiseTexture;

	// Attributes
	in vec3 position;
	in vec3 normal;
	in vec3 coords;
	in int vindex;


	// Outputs
	out vec3 vNormal;
	out vec3 wNormal;
	out vec3 vCoords;
	out float idx;
	
	#define saturate(a) clamp( a, 0.0, 1.0 )
`;	