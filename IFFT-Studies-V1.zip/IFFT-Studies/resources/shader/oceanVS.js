export const oceanVS = `

/*
const int NUM_STEPS = 8;
const float PI	 	= 3.141592;
const float EPSILON	= 1e-3;
#define EPSILON_NRM (0.1 / iResolution.x)
#define AA

// sea
const int ITER_GEOMETRY = 3;
const int ITER_FRAGMENT = 5;
const float SEA_HEIGHT = 0.6;
const float SEA_CHOPPY = 4.0;
const float SEA_SPEED = 0.8;
const float SEA_FREQ = 0.16;
const vec3 SEA_BASE = vec3(0.0,0.09,0.18);
const vec3 SEA_WATER_COLOR = vec3(0.8,0.9,0.6)*0.6;
#define SEA_TIME (1.0 + iTime * SEA_SPEED)
const mat2 octave_m = mat2(1.6,1.2,-1.2,1.6);
*/






	vec3 orthogonal(vec3 v) {
		return normalize(abs(v.x) > abs(v.z) ? vec3(-v.y, v.x, 0.0) : vec3(0.0, -v.z, v.y));
	}

	//-----------------


	void main(){

		idx = float(vindex);

		ivec2 texSize = textureSize(vertexTexture, 0);
   	float texWidth = float(texSize.x);
   	float texHeight = float(texSize.y);
   	int colIdx = int(floor(idx / texWidth));
   	int rowIdx = int(mod(idx, texHeight));
		vec3 positionD = texelFetch(vertexTexture, ivec2(rowIdx, colIdx), 0).rgb;
		vec3 normalD = texelFetch(normalTexture, ivec2(rowIdx, colIdx), 0).rgb;
	
		vec3 wpos = (modelMatrix * vec4(positionD, 1.0)).xyz;
		float displacement = getHeight(wpos);
		vec3 displacedPosition = positionD + normalD * displacement;
  
		vec3 displacedEdges = FixEdgesAndSkirts(vindex, texWidth, texHeight);
  
		if(dot(displacedEdges, displacedEdges) > 0.){
			displacedPosition = displacedEdges;
		}
		
		vCoords = coords;
		vNormal = normalize(normalD);
		gl_Position = projectionMatrix * modelViewMatrix * vec4(displacedPosition, 1.0);
		
		
	}
`;