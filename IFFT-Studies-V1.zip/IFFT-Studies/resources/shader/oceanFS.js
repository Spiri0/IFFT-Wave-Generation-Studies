export const oceanFS = `



	// returns intensity of diffuse reflection
	vec3 diffuseLighting(vec3 N, vec3 L){
		// calculation as for Lambertian reflection
		float diffuseTerm = clamp(dot(N, L), 0., 1.) ;
		//return u_matDiffuseReflectance * u_lightDiffuseIntensity * diffuseTerm;
		return  vec3(1.)*diffuseTerm;
	}

	// returns intensity of specular reflection
	vec3 specularLighting(vec3 N, vec3 L, vec3 V){
		float specularTerm = 0.;

		// calculate specular reflection only if
		// the surface is oriented to the light source
		if(dot(N, L) > 0.){
			// half vector
		//	vec3 R = reflect(-L, N);
			vec3 H = normalize(L + V);
			specularTerm = pow(dot(N, H), 64.);
	//		float specAngle = max(dot(R, V), 0.0);
	//		float specular = pow(specAngle, 64.);
		}
		//return u_matSpecularReflectance * u_lightSpecularIntensity * specularTerm;
		return vec3(1.)*specularTerm*0.75;
		//return vec3(1.)*specular*10.;
	}





	vec4 _CalculateLighting(vec3 lightDirection, vec3 lightColour, vec3 worldSpaceNormal, vec3 planetNormal, vec3 viewDirection) {
		float diffuse = saturate(dot(worldSpaceNormal, lightDirection));
		
		//float lambertian = max(dot(lightDirection, planetNormal), 0.0);
		vec3 diffuseLight = diffuseLighting(planetNormal, lightDirection);
		//vec3 reflectDir = reflect(-lightDirection, worldSpaceNormal); 
		
		
		vec3 specLight = specularLighting(worldSpaceNormal,  lightDirection,  viewDirection);
		
		
		return vec4(4.*diffuseLight + specLight, 1.0);

	}


	vec4 _ComputeLighting(vec3 worldSpaceNormal, vec3 sunDir, vec3 viewDirection, vec3 planetNormal) {
		vec4 lighting;
  
		lighting += _CalculateLighting(sunDir, 1.0 * vec3(1.0, 1.0, 1.0), worldSpaceNormal, planetNormal, viewDirection);
  
		return lighting;
	}

	//****************

	vec3 orthogonal(vec3 v) {
		return normalize(abs(v.x) > abs(v.z) ? vec3(-v.y, v.x, 0.0) : vec3(0.0, -v.z, v.y));
	}

	//****************


	vec3 scaledPos(vec3 pos, float scale) {

		float frac = 1./scale;
		
		return vec3(
			frac - abs(mod(scale * pos.x, frac*2.)-frac), 
			frac - abs(mod(scale * pos.y, frac*2.)-frac),
			frac - abs(mod(scale * pos.z, frac*2.)-frac)
		);	
	}


void main() {

	vec3 worldPosition = vCoords;
	vec3 eyeDirection = normalize(worldPosition - cameraPosition);
	vec3 sunDir = normalize(vec3(1., 0.3, -1.15));//normalize(worldPosition - sunPosition);
	
	/*
	vec3 worldSpaceNormal = vNormal;
	vec3 planetNormal = wNormal;

	vec4 lighting = _ComputeLighting(worldSpaceNormal, -sunDir, -eyeDirection, planetNormal);
  
	
	vec3 diffuseLight = diffuseLighting(planetNormal, -sunDir);	
	vec3 specLight = specularLighting(worldSpaceNormal, -sunDir, -eyeDirection);
	
	
	vec3 finalColour = color * diffuseLight + specLight;
*/


	//out_FragColor = vec4(finalColour, 1.);


		//Calculate surface Normal

		float ds = 0.01;	//hardcoded, need a better solution!
		vec3 tangent = orthogonal(vNormal);
		vec3 bitangent = normalize(cross(vNormal, tangent));
		vec3 neighbour1 = vCoords + tangent * ds;
		vec3 neighbour2 = vCoords + bitangent * ds;

		float displacement0 = 3. * getHeight(vCoords);
		float displacement1 = 3. * getHeight(neighbour1);
		float displacement2 = 3. * getHeight(neighbour1);

		vec3 displacedPosition = vCoords + vNormal * displacement0;
		vec3 displacedNeighbour1 = neighbour1 + vNormal * displacement1;
		vec3 displacedNeighbour2 = neighbour2 + vNormal * displacement2;

		vec3 displacedTangent = displacedNeighbour1 - displacedPosition;
		vec3 displacedBitangent = displacedNeighbour2 - displacedPosition;
	
		vec3 displacedNormal = normalize(cross(displacedTangent, displacedBitangent));




//		vec3 noiseTex = texture(noiseTexture, scaledPos(vCoords*0.1, 1.).xz).rgb;
		//vec3 noiseTex = texture(noiseTexture, abs(vCoords).xz/1000.).rgb;


//		float weight = getHeight(vCoords*0.1);
//		float weight = fbmM(vCoords.xz);


		float ldotn = 1.-dot(displacedNormal, -sunDir);

		//out_FragColor = vec4(normalize(worldPosition), 1.);
//		out_FragColor = vec4(noiseTex, 1.0) + vec4(0.2);
//		out_FragColor = vec4(0.005*displacement0*vec3(1.), 1.0);
		out_FragColor = vec4(ldotn * vec3(0.1, 0.3, 0.6) + 0.25 * vec3(0.05, 0.1, 0.4), 1.);
		//out_FragColor = vec4(vNormal, 1.);
		//out_FragColor = vec4(displacedNormal * vec3(1.), 1.);

		//out_FragColor = normalize(neighbours) * (1. - normalize(neighbours).a/2.);
	
}
`;



//***************************************************************************************