export const FixEdgesAndSkirts = `


	vec3 lerpPos(int i, int i1, int i2, float p, float width, float height){
	
		int colIdx1 = int(floor(float(i1) / width));
   	int rowIdx1 = int(mod(float(i1), height));
		vec3 norm1 = texelFetch(normalTexture, ivec2(rowIdx1, colIdx1), 0).rgb;	
		vec3 positionD1 = texelFetch(vertexTexture, ivec2(rowIdx1, colIdx1), 0).rgb;

   	int colIdx2 = int(floor(float(i2) / width));
   	int rowIdx2 = int(mod(float(i2), height));
		vec3 norm2 = texelFetch(normalTexture, ivec2(rowIdx2, colIdx2), 0).rgb;						
		vec3 positionD2 = texelFetch(vertexTexture, ivec2(rowIdx2, colIdx2), 0).rgb;

		vec3 wpos1 = (modelMatrix * vec4(positionD1, 1.0)).xyz;
		vec3 wpos2 = (modelMatrix * vec4(positionD2, 1.0)).xyz;

		float displacement1 = getHeight(wpos1);		
		float displacement2 = getHeight(wpos2);		
										
		float lerpfrac = mix(displacement1, displacement2, p);


   	int colIdx = int(floor(float(i) / width));
   	int rowIdx = int(mod(float(i), height));
		vec3 norm = texelFetch(normalTexture, ivec2(rowIdx, colIdx), 0).rgb;					
		vec3 pos = texelFetch(vertexTexture, ivec2(rowIdx, colIdx), 0).rgb;

		vec3 result = pos + norm * lerpfrac;

		return result;
	}


	vec3 FixEdgesAndSkirts(int index, float width, float height){
		int realResolution = resolution + 2;
		int effectiveResolution = resolution;


		if(int(neighbours.x) > 1){
			int x = 1;
			int stride = int(neighbours.x);
			
			for (int z = 1; z <= realResolution-1-stride; z+=stride) {			
				int i1 = x * (realResolution + 1) + z;
				int i2 = x * (realResolution + 1) + (z + stride);			
				for (int s = 1; s < stride; ++s){
					int i = x * (realResolution + 1) + z + s;
					float p = float(s)/float(stride);
					if(index == i){
					
						return lerpPos(i, i1, i2, p, width, height);
						
					}
				}
			}			
		}//end if


		if(int(neighbours.y) > 1){
			int z = realResolution - 1;
			int stride = int(neighbours.y);				

			for (int x = 1; x <= realResolution-1-stride; x+=stride) {
				int i1 = x * (realResolution + 1) + z;
				int i2 = (x + stride) * (realResolution + 1) + z;
				for (int s = 1; s < stride; ++s){
					int i = (x + s) * (realResolution + 1) + z;
					float p = float(s)/float(stride);
					if(index == i){	
	
						return lerpPos(i, i1, i2, p, width, height);	
						
					}
				}
			}
		}//end if


		if(int(neighbours.z) > 1){
			int x = realResolution - 1;
			int stride = int(neighbours.z);				

			for (int z = 1; z <= realResolution-1-stride; z+=stride) {
				int i1 = x * (realResolution + 1) + z;
				int i2 = x * (realResolution + 1) + (z + stride);
				for (int s = 1; s < stride; ++s){
					int i = x * (realResolution + 1) + z + s;
					float p = float(s)/float(stride);
					if(index == i){	
		
						return lerpPos(i, i1, i2, p, width, height);
	
					}
				}
			}
		}//end if


		if(int(neighbours.w) > 1){
			int z = 1;
			int stride = int(neighbours.w);				

			for (int x = 1; x <= realResolution-1-stride; x+=stride) {
				int i1 = x * (realResolution + 1) + z;
				int i2 = (x + stride) * (realResolution + 1) + z;
				for (int s = 1; s < stride; ++s){
					int i = (x + s) * (realResolution + 1) + z;
					float p = float(s)/float(stride);
					if(index == i){	

						return lerpPos(i, i1, i2, p, width, height);
						
					}
				}
			}
		}//end if




		//SkirtCorners

		if(index == 0){
			int colIdx = int(floor(float(realResolution + 2) / width));
   		int rowIdx = int(mod(float(realResolution + 2), height));
			vec3 norm = texelFetch(normalTexture, ivec2(rowIdx, colIdx), 0).rgb;					
			vec3 pos = texelFetch(vertexTexture, ivec2(rowIdx, colIdx), 0).rgb;		
			return pos - norm * 10.;		
		}
		
		if(index == realResolution){
			int colIdx = int(floor(float(realResolution * 2) / width));
   		int rowIdx = int(mod(float(realResolution * 2), height));
			vec3 norm = texelFetch(normalTexture, ivec2(rowIdx, colIdx), 0).rgb;					
			vec3 pos = texelFetch(vertexTexture, ivec2(rowIdx, colIdx), 0).rgb;		
			return pos - norm * 10.;		
		}

		if(index == (realResolution + 1) * realResolution){
			int colIdx = int(floor(float((realResolution + 1) * realResolution - realResolution) / width));
   		int rowIdx = int(mod(float((realResolution + 1) * realResolution - realResolution), height));
			vec3 norm = texelFetch(normalTexture, ivec2(rowIdx, colIdx), 0).rgb;					
			vec3 pos = texelFetch(vertexTexture, ivec2(rowIdx, colIdx), 0).rgb;		
			return pos - norm * 10.;		
		}

		if(index == (realResolution + 1) * (realResolution + 1) - 1){
			int colIdx = int(floor(float((realResolution + 1) * (realResolution + 1) - realResolution - 3) / width));
   		int rowIdx = int(mod(float((realResolution + 1) * (realResolution + 1) - realResolution - 3), height));
			vec3 norm = texelFetch(normalTexture, ivec2(rowIdx, colIdx), 0).rgb;					
			vec3 pos = texelFetch(vertexTexture, ivec2(rowIdx, colIdx), 0).rgb;		
			return pos - norm * 10.;		
		}

		
		//SkirtEdges

		if(index >= 1 && index <= realResolution - 1){
			int colIdx = int(floor(float(realResolution + 1 + index) / width));
   		int rowIdx = int(mod(float(realResolution + 1 + index), height));
			vec3 norm = texelFetch(normalTexture, ivec2(rowIdx, colIdx), 0).rgb;					
			vec3 pos = texelFetch(vertexTexture, ivec2(rowIdx, colIdx), 0).rgb;		
			return pos - norm * 10.;		
		}

		if(index >= (realResolution+1) * realResolution+1 && index <= (realResolution+1) * (realResolution+1) - 2){
			int colIdx = int(floor(float(index - realResolution - 1) / width));
   		int rowIdx = int(mod(float(index - realResolution - 1), height));
			vec3 norm = texelFetch(normalTexture, ivec2(rowIdx, colIdx), 0).rgb;					
			vec3 pos = texelFetch(vertexTexture, ivec2(rowIdx, colIdx), 0).rgb;		
			return pos - norm * 10.;		
		}

		if(mod(float(index), float(realResolution + 1)) == 0.){
			int colIdx = int(floor(float(index + 1) / width));
   		int rowIdx = int(mod(float(index + 1), height));
			vec3 norm = texelFetch(normalTexture, ivec2(rowIdx, colIdx), 0).rgb;					
			vec3 pos = texelFetch(vertexTexture, ivec2(rowIdx, colIdx), 0).rgb;		
			return pos - norm * 10.;		
		}

		if(mod(float(index + 1), float(realResolution + 1)) == 0.){
			int colIdx = int(floor(float(index - 1) / width));
   		int rowIdx = int(mod(float(index - 1), height));
			vec3 norm = texelFetch(normalTexture, ivec2(rowIdx, colIdx), 0).rgb;					
			vec3 pos = texelFetch(vertexTexture, ivec2(rowIdx, colIdx), 0).rgb;		
			return pos - norm * 10.;		
		}

	
		return vec3(0.);
	}
`;