import {THREE} from './three-defs.js';
import {entity} from './entity.js';

import { commonVS } from "../resources/shader/IFFT/commonVS.js";
import { initialSpectrumFS } from "../resources/shader/IFFT/initialSpectrumFS.js";
import { currentSpectrumFS } from "../resources/shader/IFFT/currentSpectrumFS.js";
import { timeSpectrumFS } from "../resources/shader/IFFT/timeSpectrumFS.js";
import { phaseFS } from "../resources/shader/IFFT/phaseFS.js";
import { displacementHorizontalFS } from "../resources/shader/IFFT/displacementHorizontalFS.js";
import { displacementVerticalFS } from "../resources/shader/IFFT/displacementVerticalFS.js";


//Code adapted from Phil Crowther (philcrowther.com)


export const fft_generators = (() => {

	class FFTGenerators extends entity.Component {
		constructor(params) {
			super();
			this.Init(params);
    }


		Init(params) {
			this.params_ = params;
			
			//The screenQuad is the scene. So the camera does not have to be configured and positioned.
			//Because the screenQuad is flat, there is no perspective. Therefore it looks the same for a perspective camera as for an orthographic one. Since the screenQuad also serves as a scene, it is everything that exists for the camera. Therefore the simplest form of camera can be used, just THREE.Camera();
			
			this.textureCamera = new THREE.Camera();	
			this.screenQuad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2));	 



			this.Res = 512;
			this.GrdSiz = 804.67;				// Size of Smallest Grid Square (meters)
			this.WndSpd = 20.0;
			this.WndHdg = 0.0;
			this.Choppy = 1.25;
			this.WavMax = 5;						// Maximum wave height (set height of outer waves)
			this.WaveSpd = 2;
			
			this.nowTim = 0;
			this.difTim = 0;
			this.oldTim = 0;

			this.changed = true;
			this.initial = true;
			this.pingPhase = true;


			let BaseParams = {
				format: THREE.RGBAFormat,
				stencilBuffer: false,
				depthBuffer: false,
				premultiplyAlpha: false,
				type: THREE.FloatType
			};
			// Set Parameters
			//NRP = NearestRepeatParams
			//NCP = NearestClampParams
			//LRP = LinearRepeatParams
			let NRP = JSON.parse(JSON.stringify(BaseParams));	
			NRP.minFilter = NRP.magFilter = THREE.NearestFilter;
			NRP.wrapS = NRP.wrapT = THREE.RepeatWrapping;
			let NCP = JSON.parse(JSON.stringify(BaseParams));	
			NCP.minFilter = NCP.magFilter = THREE.NearestFilter;
			NCP.wrapS = NCP.wrapT = THREE.ClampToEdgeWrapping;
			let LRP = JSON.parse(JSON.stringify(BaseParams));
			LRP.minFilter = THREE.LinearMipMapLinearFilter;		
			LRP.generateMipmaps = true;
			LRP.magFilter = THREE.LinearFilter;
			LRP.wrapS = LRP.wrapT = THREE.RepeatWrapping;
			//= Set Render Targets =========================================
			// 8 Buffers of Size = 512x512
	
			this.initialSpectrumFramebuffer = new THREE.WebGLRenderTarget(this.Res, this.Res, NRP);
			this.pingPhaseFramebuffer = new THREE.WebGLRenderTarget(this.Res, this.Res, NCP);
			this.pongPhaseFramebuffer = new THREE.WebGLRenderTarget(this.Res, this.Res, NCP);
			this.spectrumFramebuffer = new THREE.WebGLRenderTarget(this.Res, this.Res, NCP);
			this.pingTransformFramebuffer = new THREE.WebGLRenderTarget(this.Res, this.Res, NCP);
			this.pongTransformFramebuffer = new THREE.WebGLRenderTarget(this.Res, this.Res, NCP);
			this.displacementMapFramebuffer = new THREE.WebGLRenderTarget(this.Res, this.Res, LRP);
			this.normalMapFramebuffer = new THREE.WebGLRenderTarget(this.Res, this.Res, LRP);


			// 1 - Initial Spectrum			
			this.materialInitialSpectrum = new THREE.RawShaderMaterial({ 
				glslVersion: THREE.GLSL3,
				uniforms: { 
					wind: {value: new THREE.Vector2(10, 10)},
					grdres: {value: this.Res},
					grdsiz: {value: this.GrdSiz},
				}, 
				vertexShader: commonVS, 
				fragmentShader: initialSpectrumFS, 
				depthTest: false, 
			});

			// 2 - Current Phase
			this.materialPhase = new THREE.RawShaderMaterial({ 
				glslVersion: THREE.GLSL3,
				uniforms: { 
					phases: {value: null},
					time: {value: 0},
					grdres: {value: this.Res},
					grdsiz: {value: this.GrdSiz},
				}, 
				vertexShader: commonVS, 
				fragmentShader: phaseFS, 
				depthTest: false, 
			}); 

			// 3 - Current Spectrum
			this.materialSpectrum = new THREE.RawShaderMaterial({ 
				glslVersion: THREE.GLSL3,
				uniforms: { 
					grdsiz: {value: this.GrdSiz},
					grdres: {value: this.Res},
					choppy: {value: this.Choppy},
					phases: {value: null},
					begFFT: {value: null},
				}, 
				vertexShader: commonVS, 
				fragmentShader: currentSpectrumFS, 
				depthTest: false, 
			});

	
			const u_displacement = {
				u_input: {value: null},
				transformSize: {value: this.Res}, //wav_.Res
				subtransformSize: {value: this.GrdSiz}		//wav_.Siz			
			}
						
			// 4 - Fragment Shader - Displacement Map
			// 4A - Horizontal wave vertices used for FFT
			this.materialOceanHorizontal = new THREE.RawShaderMaterial({ 
				glslVersion: THREE.GLSL3,
				uniforms: u_displacement,
				vertexShader: commonVS,	
				fragmentShader: displacementHorizontalFS,
				depthTest: false
			});
	
			// 4B - Vertical wave vertices used for FFT
			this.materialOceanVertical  = new THREE.RawShaderMaterial({ 
				glslVersion: THREE.GLSL3,
				uniforms: u_displacement,
				vertexShader: commonVS,	
				fragmentShader: displacementVerticalFS,
				depthTest: false
			});			


		
			this.pingPhaseTexture = this.PhaseDataTexture();

			this.materialOceanHorizontal.blending = 0;
			this.materialOceanVertical.blending = 0;
			this.materialInitialSpectrum.blending = 0;
			this.materialPhase.blending = 0;
			this.materialSpectrum.blending = 0;
			//this.materialNormal.blending = 0;


			this.timeSpectrum = this.TimeSpectrum(params);	//from paper, looks good
		}


		Update(_) {
	
			this.nowTim = this.params_.clock.getElapsedTime();
			this.difTim = this.nowTim-this.oldTim;
			this.oldTim = this.nowTim;
		
			this.InitialSpectrum(this.params_);	
			this.CurrentPhase(this.params_);
			this.CurrentSpectrum(this.params_);
			this.DisplacementMap(this.params_);
		
		
		
			this.timeSpectrum.uniforms.time.value = this.params_.clock.getElapsedTime();
			this.timeSpectrum.uniformsNeedUpdate = true;
		}



		InitialSpectrum(params){	
			// 1. Initial Spectrum
			if (this.changed) {
				this.screenQuad.material = this.materialInitialSpectrum;
				this.initialSpectrumFramebuffer.texture.needsUpdate = true;
				params.renderer.setRenderTarget(this.initialSpectrumFramebuffer);
				params.renderer.render(this.screenQuad, this.textureCamera);
				params.renderer.setRenderTarget(null);
			}
		}

		CurrentPhase(params){	
			// 2. Current Wave Phase (uses Ping and Pont Buffers)
			this.screenQuad.material = this.materialPhase;				
			if(this.initial) {
				this.materialPhase.uniforms.phases.value = this.pingPhaseTexture;
				this.initial = false;
			}			
			else{
				this.materialPhase.uniforms.phases.value = 
				this.pingPhase ? this.pingPhaseFramebuffer.texture : this.pongPhaseFramebuffer.texture;
			}				
			this.materialPhase.uniforms.time.value = this.difTim * this.WaveSpd;
			this.materialPhase.uniformsNeedUpdate = true;
			params.renderer.setRenderTarget(
				this.pingPhase ? this.pongPhaseFramebuffer : this.pingPhaseFramebuffer);
			params.renderer.render(this.screenQuad, this.textureCamera);
			params.renderer.setRenderTarget(null);
			this.pingPhase = !this.pingPhase;
		}

		CurrentSpectrum(params){
			// 3. renderSpectrum (combination of initial Spectrum and Wave Phases)
			this.screenQuad.material = this.materialSpectrum;
			this.materialSpectrum.uniforms.begFFT.value = this.initialSpectrumFramebuffer.texture;
			this.materialSpectrum.uniforms.phases.value = 
			this.pingPhase ? this.pingPhaseFramebuffer.texture : this.pongPhaseFramebuffer.texture;
			this.materialSpectrum.uniformsNeedUpdate = true;			
			params.renderer.setRenderTarget(this.spectrumFramebuffer);
			params.renderer.render(this.screenQuad, this.textureCamera);
			params.renderer.setRenderTarget(null);
		}

	
		//**********

		DisplacementMap(params){
		
			// 4. Displacement Map (iterations = 9*2
			let iterations = Math.log2(this.Res)*2; // log2(512) = 9 *2 = 18
			this.screenQuad.material = this.materialOceanHorizontal;
			let subtransformProgram = this.materialOceanHorizontal;
			// Processus 0-N
			// material = materialOceanHorizontal
			// 0 : material(spectrumFramebuffer) > pingTransformFramebuffer
			// i%2==0 : material(pongTransformFramebuffer) > pingTransformFramebuffer
			// i%2==1 : material(pingTransformFramebuffer) > pongTransformFramebuffer
			// i == N/2 : material = materialOceanVertical
			// i%2==0 : material(pongTransformFramebuffer) > pingTransformFramebuffer
			// i%2==1 : material(pingTransformFramebuffer) > pongTransformFramebuffer
			// N-1 : materialOceanVertical(pingTransformFramebuffer / pongTransformFramebuffer) > displacementMapFramebuffer

			let frameBuffer, inputBuffer = 0;
			for (let i = 0; i < iterations-1; i++) {
				if (i === 0) {
					inputBuffer = this.spectrumFramebuffer;
					frameBuffer = this.pingTransformFramebuffer;
				} 
				else if (i%2 === 1) {
					inputBuffer = this.pingTransformFramebuffer;
					frameBuffer = this.pongTransformFramebuffer;
				}
				else {
					inputBuffer = this.pongTransformFramebuffer;
					frameBuffer = this.pingTransformFramebuffer;
				}	
				if (i === iterations/2) {// switch to vertical at midway point
					subtransformProgram = this.materialOceanVertical;
					this.screenQuad.material = this.materialOceanVertical;
				}
				subtransformProgram.uniforms.u_input.value = inputBuffer.texture;
				subtransformProgram.uniforms.subtransformSize.value = Math.pow(2,(i%(iterations/2)+1));
				subtransformProgram.uniformsNeedUpdate = true;	
				params.renderer.setRenderTarget(frameBuffer);
				params.renderer.render(this.screenQuad, this.textureCamera);
				params.renderer.setRenderTarget(null);
			}
			// Final Render to Displacement Map
			inputBuffer = ((iterations%2 === 0)? this.pingTransformFramebuffer : this.pongTransformFramebuffer);
			frameBuffer = this.displacementMapFramebuffer;
			subtransformProgram.uniforms.u_input.value = inputBuffer.texture;
			subtransformProgram.uniforms.subtransformSize.value = this.Res;
			subtransformProgram.uniformsNeedUpdate = true;	
			params.renderer.setRenderTarget(frameBuffer);
			params.renderer.render(this.screenQuad, this.textureCamera);
			params.renderer.setRenderTarget(null);
		}


		PhaseDataTexture(){
			let phaseArray = new Float32Array(this.Res * this.Res * 4);
			for (let y = 0; y < this.Res; y++) {
				for (let x = 0; x < this.Res; x++) {
					phaseArray[y*this.Res*4 + x*4] = Math.random() * 2.0 * Math.PI;
					phaseArray[y*this.Res*4 + x*4+1] = 0.0;
					phaseArray[y*this.Res*4 + x*4+2] = 0.0;
					phaseArray[y*this.Res*4 + x*4+3] = 0.0;
				}
			}
			const pingPhaseTexture = new THREE.DataTexture(phaseArray, this.Res, this.Res, THREE.RGBAFormat, THREE.FloatType);
			
			pingPhaseTexture.minFilter = THREE.NearestFilter;
			pingPhaseTexture.magFilter = THREE.NearestFilter;
			pingPhaseTexture.wrapS = THREE.ClampToEdgeWrapping;
			pingPhaseTexture.wrapT = THREE.ClampToEdgeWrapping;
			pingPhaseTexture.needsUpdate = true;
			
			return pingPhaseTexture;
		}


		//**********


		TimeSpectrum(params){	//h(k, t)
			
			var uniform = {
				time: {value: 0},
			}

			return new THREE.RawShaderMaterial({
				glslVersion: THREE.GLSL3,
				uniforms: uniform,
				vertexShader: commonVS,
				fragmentShader: timeSpectrumFS,
				depthTest: false,
			});		
		}	
		
		
		
  }


  return {
      FFTGenerators: FFTGenerators,
  };

})();